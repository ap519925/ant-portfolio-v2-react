<?php

/* this is used for adding in global values and global hook connections*/
//function template_preprocess(&$variables, $hook){}



function ActiveLanding_html_head_alter(&$head_elements) {
	// replace the meta content-type tag
	if(theme_get_setting('html_version')){
		$head_elements['system_meta_content_type']['#attributes'] = array('charset' => 'utf-8');
	}
	// remove meta tag generator from head
	if(!theme_get_setting('meta_generator')){
		unset($head_elements['system_meta_generator']);
	}
}

function ActiveLanding_preprocess_block(&$variables) {
  // In the header region visually hide block titles.
  switch($variables['block']->region){
	case 'header':
	case 'main_nav':
	case 'main_nav_bottom':
	case 'sub_header':
	case 'footer_sub_link':
	case 'banner':
	case 'copyright':
		$variables['title_attributes_array']['class'][] = 'element-invisible';
	break;
  }
  
  /*
  if ($variables['block']->region == 'header') {
    $variables['title_attributes_array']['class'][] = 'element-invisible';
  }
  */
}

function ActiveLanding_preprocess_page(&$variables){
/*
		$status = drupal_get_http_header("status");
		if($status == '403 Forbidden'){
			$variables['theme_hook_suggestions'][] = 'page__403';
		}
		if($status == '404 Not Found'){
			$variables['theme_hook_suggestions'][] = 'page__404';
		}
*/
}


function ActiveLanding_form_alter(&$form, &$form_state, $form_id){
	if($form['#id'] == 'user-login-form'){
		
	}
}

function ActiveLanding_preprocess_html(&$variables) {
	drupal_add_css('http://netdna.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.css',array('type' => 'external'));
	drupal_add_css('http://fonts.googleapis.com/css?family=Grand+Hotel',array('type' => 'external'));
}

/*
function TestThemeOne_theme(){
	$items = array();
	// create custom user-login.tpl.php
	$items['user_login'] = array(
		'render element' => 'form',
		'path' => drupal_get_path('theme', 'TestThemeOne') . '/templates',
		'template' => 'user-login',
		'preprocess functions' => array(
			'TestThemeOne_preprocess_user_login'
		),
	);
	return $items;
}*/
