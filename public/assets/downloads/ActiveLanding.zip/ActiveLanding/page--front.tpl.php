<?php
$show_content = theme_get_setting('show_content');
$facebook_like_url = theme_get_setting('facebook_like_url');
$google_plus_url = theme_get_setting('google_plus_url');
$pinterest_url = theme_get_setting('pinterest_url');
$main_message = theme_get_setting('main_message');
$email_to_address = theme_get_setting('email_to_address');
$display_language_select = theme_get_setting('display_language_select');
?>
<div id="container">
	<nav class="navbar navbar-transparent container-fluid" style="z-index:999;" role="navigation">
	  <div class="container">
		<!-- Brand and toggle get grouped for better mobile display -->
		<div class="navbar-header">
		  <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
			<span class="sr-only">Toggle navigation</span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
		  </button>
		</div>

		<!-- Collect the nav links, forms, and other content for toggling -->
		<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
		<?php if($display_language_select): ?>
		  <ul class="nav navbar-nav">
			<li class="dropdown">
				  <a href="#" class="dropdown-toggle" data-toggle="dropdown"> 
					<img src="<?php print base_path() . path_to_theme() ?>/images/flags/US.png"/>
					English(US) 
					<b class="caret"></b>
				  </a>
				  <ul class="dropdown-menu">
					<li><a href="#"><img src="<?php print base_path() . path_to_theme() ?>/images/flags/DE.png"/> Deutsch</a></li>
					<li><a href="#"><img src="<?php print base_path() . path_to_theme() ?>/images/flags/CN.png"/> Chinese</a></li>
					<li><a href="#"><img src="<?php print base_path() . path_to_theme() ?>/images/flags/GB.png"/> English(UK)</a></li>
					<li><a href="#"><img src="<?php print base_path() . path_to_theme() ?>/images/flags/FR.png"/> Fran�ais</a></li>
					<li><a href="#"><img src="<?php print base_path() . path_to_theme() ?>/images/flags/RO.png"/> Rom�na</a></li>
					<li><a href="#"><img src="<?php print base_path() . path_to_theme() ?>/images/flags/IT.png"/> Italiano</a></li>
					
					<li class="divider"></li>
					<li><a href="#"><img src="<?php print base_path() . path_to_theme() ?>/images/flags/ES.png"/> Espa�ol <span class="label label-default">soon</span></a></li>
					<li><a href="#"><img src="<?php print base_path() . path_to_theme() ?>/images/flags/BR.png"/> Portugu�s <span class="label label-default">soon</span></a></li>
					<li><a href="#"><img src="<?php print base_path() . path_to_theme() ?>/images/flags/JP.png"/> ??? <span class="label label-default">soon</span></a></li>
					<li><a href="#"><img src="<?php print base_path() . path_to_theme() ?>/images/flags/TR.png"/> T�rk�e <span class="label label-default">soon</span></a></li> 
				  </ul>
			</li>

		  </ul>
		<?php endif; ?>
		  <ul class="nav navbar-nav navbar-right">
			<?php if($facebook_like_url): ?>
				<li>
					<a href="<?php echo $facebook_like_url; ?>"><i class="fa fa-facebook-square"></i>Like</a>
				</li>
			<?php endif; ?>
			<?php if($google_plus_url): ?>	
				 <li>
					<a href="<?php echo $google_plus_url; ?>"><i class="fa fa-google-plus-square"></i>Plus</a>
				</li>
			<?php endif; ?>
			<?php if($pinterest_url): ?>	
				 <li>
					<a href="<?php echo $pinterest_url; ?>"><i class="fa fa-pinterest"></i>Pin</a>
				</li>
			<?php endif; ?>
		   </ul>
		  
		</div><!-- /.navbar-collapse -->
	  </div><!-- /.container -->
	</nav>

	<div class="main" style="background-image: url('images/video_bg.jpg')">
			<video id="video_background" preload="auto" autoplay loop muted="muted" volume="0">  
				<source src="<?php print base_path() . path_to_theme() ?>/images/NYC.mp4#t=7,47" type="video/mp4"> 
				Video not supported 
			</video>
	<!--    Change the image source '/images/video_bg.jpg')" with your favourite image.     -->
		
		<div class="cover black" data-color="black"></div>
		 
	<!--   You can change the black color for the filter with those colors: blue, green, red, orange       -->

		<div class="container">
			<h1 class="logo cursive"><?php echo variable_get('site_name', 'Drupal'); ?></h1>
	<!--  H1 can have 2 designs: "logo" and "logo cursive"           -->
			<?php if ($page['banner']): ?>
				<?php print render($page['banner']); ?>
			<?php endif; ?>
			<div class="content">
				<div class="subscribe">
					<h5 class="info-text"><?php echo $main_message; ?></h5>
					<div class="row">
						<div class="col-md-4 col-md-offset-4 col-sm6-6 col-sm-offset-3 ">
							<?php if($email_to_address): ?>
							<form action="<?php echo $email_to_address; ?>" class="form-inline" role="form">
							  <div class="form-group">
								<label class="sr-only" for="exampleInputEmail2">Email address</label>
								<input type="email" class="form-control transparent" placeholder="Your email here...">
							  </div>
							  <button type="submit" class="btn btn-warning btn-fill">Notify Me</button>
							</form>
							<?php endif; ?>
						</div>
					</div>
				</div>
			</div>
			<?php if($show_content): ?>
				<?php print render($page['content']); ?>
			<?php endif; ?>
		</div>
		<?php if ($page['footer']): ?>
			<?php print render($page['footer']); ?>
		<?php endif; ?>
<!--
		<div class="footer">
		  <div class="container">Unigreet Co. <i class="fa fa-heart heart"></i></div>
		</div>
-->
	 </div>
</div>
