<?php
/*
* This file adds in all the admin settings for the theme.
*/

function ActiveLanding_form_system_theme_settings_alter(&$form, $form_state) {
	$form['group1'] = array(
		'#type' => 'fieldset',
		'#title' => t('Development'),
		'#collapsible' => true,
		'#collapsed' => false,  
	);
	
	$form['group1']['dev_mode_banner'] = array(
		'#type'          => 'checkbox',
		'#title'         => t('Development Mode'),
		'#default_value' => theme_get_setting('dev_mode_banner'),
		'#description'   => t("This will display a development banner on the site."), 
	);
	


	$form['group2'] = array(
		'#type' => 'fieldset',
		'#title' => t('Page Rendering'),
		'#collapsible' => true,
		'#collapsed' => false,  
	);

	$form['group2']['html_version'] = array(
		'#type'          => 'checkbox',
		'#title'         => t('HTML5'),
		'#default_value' => theme_get_setting('html_version'),
		'#description'   => t("Use HTML5 if checked. HTML4 if unchecked"), 
	);
  
	$form['group2']['ie_compatibility'] = array(
		'#type'          => 'checkbox',
		'#title'         => t('IE Compatibility'),
		'#default_value' => theme_get_setting('ie_compatibility'),
		'#description'   => t("When checked IE Compatibility will enable IE fixes."), 
	);
	
	$form['group2']['show_landing_nav'] = array(
		'#type'          => 'checkbox',
		'#title'         => t('Show Landing Nav'),
		'#default_value' => theme_get_setting('show_landing_nav'),
		'#description'   => t("When checked will show the Landing Page Navication"), 
	);
	
	$form['group2']['show_content'] = array(
		'#type'          => 'checkbox',
		'#title'         => t('Show Content'),
		'#default_value' => theme_get_setting('show_content'),
		'#description'   => t("When checked will show the content section on the home page"), 
	);

	$form['group2']['display_language_select'] = array(
		'#type'          => 'checkbox',
		'#title'         => t('Display Language Select'),
		'#default_value' => theme_get_setting('display_language_select'),
		'#description'   => t("Display Language Select"), 
	);

	$form['group2']['main_message'] = array(
		'#type'          => 'textfield',
		'#title'         => t('Main Message'),
		'#default_value' => variable_get('main_message', theme_get_setting('main_message')),
		'#description'   => t("The main Messaging"), 
	);

	$form['group2']['email_to_address'] = array(
		'#type'          => 'textfield',
		'#title'         => t('Email Address'),
		'#default_value' => variable_get('email_to_address', theme_get_setting('email_to_address')),
		'#description'   => t("Email address to send notifications too."), 
	);
  
	$form['group3'] = array(
		'#type' => 'fieldset',
		'#title' => t('Meta Data'),
		'#collapsible' => true,
		'#collapsed' => false,  
	);
  
	$form['group3']['meta_generator'] = array(
		'#type'          => 'checkbox',
		'#title'         => t('Meta Generator Tag'),
		'#default_value' => theme_get_setting('meta_generator'),
		'#description'   => t("Use the Meta tag Generator. Displays information showing that this site uses Drupal."), 
	);
  
	$form['group3']['lock_scalling'] = array(
		'#type'          => 'checkbox',
		'#title'         => t('Meta ViewPort lock scalling'),
		'#default_value' => theme_get_setting('lock_scalling'),
		'#description'   => t("When enabbled this will add the viewPort meta tag in that will lock scalling to 1.0 with no user scalling."), 
	);
	
	
	$form['group4'] = array(
		'#type' => 'fieldset',
		'#title' => t('App Stores'),
		'#collapsible' => true,
		'#collapsed' => false,  
	);
	
	
	$form['group4']['itunes_app_store_id'] = array(
		'#type'          => 'textfield',
		'#title'         => t('Itunes App ID'),
		'#default_value' => variable_get('itunes_app_store_id', theme_get_setting('itunes_app_store_id')),
		'#description'   => t("If an itunes app id is provided it will prompt a user to the app when on an apple device"), 
	);
	
	$form['group4']['google_app_store_id'] = array(
		'#type'          => 'textfield',
		'#title'         => t('Google App ID'),
		'#default_value' => variable_get('google_app_store_id', theme_get_setting('google_app_store_id')),
		'#description'   => t("If a google app id is provided it will prompt a user to the app when on an android device"), 
	);

	$form['group_social'] = array(
		'#type' => 'fieldset',
		'#title' => t('Social Networking'),
		'#collapsible' => true,
		'#collapsed' => false,  
	);

	$form['group_social']['facebook_like_url'] = array(
		'#type'          => 'textfield',
		'#title'         => t('Facebook Like url'),
		'#default_value' => variable_get('facebook_like_url', theme_get_setting('facebook_like_url')),
		'#description'   => t("Facebook App ID needed for like button."), 
	);

	$form['group_social']['google_plus_url'] = array(
		'#type'          => 'textfield',
		'#title'         => t('Google Plus url'),
		'#default_value' => variable_get('google_plus_url', theme_get_setting('google_plus_url')),
		'#description'   => t("Google Plus App ID needed for plus button."), 
	);

	$form['group_social']['pinterest_url'] = array(
		'#type'          => 'textfield',
		'#title'         => t('Pinterest url'),
		'#default_value' => variable_get('pinterest_url', theme_get_setting('pinterest_url')),
		'#description'   => t("Pinterest App ID needed for button."), 
	);
}
