<?php
/*
* default template
* this template is the base template and is called on all page loads
* it brings in all the other templates.
*/

/*template variables*/
$html_version = theme_get_setting('html_version');
$ie_fixes = theme_get_setting('ie_compatibility');
$dev_mode_banner = theme_get_setting('dev_mode_banner');
$lock_scalling = theme_get_setting('lock_scalling');
$itunes_app_store_id = theme_get_setting('itunes_app_store_id');
$google_app_store_id = theme_get_setting('google_app_store_id');
$show_landing_nav = theme_get_setting('show_landing_nav');
?>


<?php if($html_version): ?>
	<!DOCTYPE html>
<?php else: ?>
	<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML+RDFa 1.0//EN"" http://www.w3.org/MarkUp/DTD/xhtml-rdfa-1.dtd">
<?php endif ?>	

<?php if($html_version): ?>
	<?php if($ie_fixes): ?>
		<!--[if lt IE 7 ]> <html class="ie6"> <![endif]-->
		<!--[if IE 7 ]> <html class="ie7"> <![endif]-->
		<!--[if IE 8 ]> <html class="ie8"> <![endif]-->
		<!--[if IE 9 ]> <html class="ie9"> <![endif]-->
		<!--[if (gt IE 9)|!(IE)]><!--> 
			<html>
		<!--<![endif]-->
	<?php else: ?>
		<html>
	<?php endif ?>
	
<?php else: ?>
	<?php if($ie_fixes): ?>
		<!--[if lt IE 7 ]>
			<html class="ie6" xmlns="http://www.w3.org/1999/xhtml" xml:lang="<?php print $language->language; ?>" version="XHTML+RDFa 1.0" dir="<?php print $language->dir; ?>"<?php print $rdf_namespaces; ?>>
		<![endif]--> 
		<!--[if IE 7 ]> 
			<html class="ie7" xmlns="http://www.w3.org/1999/xhtml" xml:lang="<?php print $language->language; ?>" version="XHTML+RDFa 1.0" dir="<?php print $language->dir; ?>"<?php print $rdf_namespaces; ?>>
		<![endif]-->
		<!--[if IE 8 ]>
			<html class="ie8" xmlns="http://www.w3.org/1999/xhtml" xml:lang="<?php print $language->language; ?>" version="XHTML+RDFa 1.0" dir="<?php print $language->dir; ?>"<?php print $rdf_namespaces; ?>>
		<![endif]-->
		<!--[if IE 9 ]>
			<html class="ie9" xmlns="http://www.w3.org/1999/xhtml" xml:lang="<?php print $language->language; ?>" version="XHTML+RDFa 1.0" dir="<?php print $language->dir; ?>"<?php print $rdf_namespaces; ?>>
		<![endif]-->	
		<!--[if (gt IE 9)|!(IE)]><!--> 
			<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="<?php print $language->language; ?>" version="XHTML+RDFa 1.0" dir="<?php print $language->dir; ?>"<?php print $rdf_namespaces; ?>>
		<!--<![endif]-->
	<?php else: ?>
		<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="<?php print $language->language; ?>" version="XHTML+RDFa 1.0" dir="<?php print $language->dir; ?>"<?php print $rdf_namespaces; ?>>
	<?php endif ?>	
<?php endif ?>

<head <?php if(!$html_version): ?> profile="<?php print $grddl_profile; ?>" <?php endif ?>>
  <?php print $head; ?>
  <!--<meta name="viewport" content="initial-scale=1">-->
  <?php if($lock_scalling): ?>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, user-scalable=no">
  <?php endif ?>
  <?php if($itunes_app_store_id): ?>
	<meta name="apple-itunes-app" content="app-id=<?php echo $itunes_app_store_id; ?>">
  <?php endif ?>
  <?php if($google_app_store_id): ?>
	<meta name="google-play-app" content="app-id=<?php echo $google_app_store_id; ?>">
	<link rel="stylesheet" href="jquery.smartbanner.css" type="text/css" media="screen">
	<script src="//ajax.googleapis.com/ajax/libs/jquery/1.8/jquery.min.js"></script>
	<script src="jquery.smartbanner.js"></script>
	<script>
	$.smartbanner({
	  title: <?php echo $google_app_store_id; ?>,
	  author: <?php echo $google_app_store_id; ?>
	});
	</script>
  <?php endif ?>
  <!--<meta name="viewport" content="width=device-width, initial-scale=1,maximum-scale=1,-scale=1">-->
  <!--<meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="viewport" content="initial-scale=1, maximum-scale=1">
  <meta name="viewport" content="user-scalable = yes">-->
  <title><?php print $head_title; ?></title>
  <?php print $styles; ?>
  <?php print $scripts; ?>
</head>
<body class="<?php print $classes; ?>" <?php print $attributes;?>>
<?php if($dev_mode_banner): ?>
	<div id="devBanner">Drupal Development Site</div>
<?php endif ?>	
  <div id="skip-link">
    <a href="#main-content" class="element-invisible element-focusable"><?php print t('Skip to main content'); ?></a>
  </div>
  <?php print $page_top; ?>
  <?php print $page; ?>
  <?php print $page_bottom; ?>
</body>
</html>